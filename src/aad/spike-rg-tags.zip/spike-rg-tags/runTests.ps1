$voModules = Get-ChildItem -Path "$PSScriptRoot\src" -Filter '*.ps1' -Recurse | Where-Object BaseName -NE 'Deploy' | Select-Object -ExpandProperty FullName
Import-Module $voModules -Global -Force

$config = [PesterConfiguration]::Default
$config.Run.Path = "$PSScriptRoot\test"
$config.TestResult.Enabled.Value = $true
$config.Output.Verbosity.Value = 'Detailed'
Invoke-Pester -Configuration $config

#Requires -Module @{ ModuleName = 'Pester'; RequiredVersion = '5.2.0' }
