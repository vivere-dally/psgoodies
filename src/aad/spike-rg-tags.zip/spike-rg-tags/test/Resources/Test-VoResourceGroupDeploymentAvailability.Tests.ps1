Describe 'Resources/Test-VoResourceGroupDeploymentAvailability' {
    It 'Force is used' {
        Test-VoResourceGroupDeploymentAvailability `
            -Location 'foo' `
            -ResourceGroupName 'bar' `
            -ResourceGroupTags @{Force = $true } `
        | Should -Be $true
    }

    It 'Resource group does not exist' {
        Mock Get-AzResourceGroup { return $null } -ParameterFilter { $Location -eq 'foo' -and $ResourceGroupName -eq 'bar' }
        Test-VoResourceGroupDeploymentAvailability `
            -Location 'foo' `
            -ResourceGroupName 'bar' `
            -ResourceGroupTags @{} `
        | Should -Be $true
    }

    It 'Resource group has malformed tags' -TestCases @(
        @{Tags = @{} },
        @{Tags = @{LockedUntil = '' } },
        @{Tags = @{LockedUntil = $null } },
        @{Tags = @{LockedUntil = '0a1b2c3d4' } }
    ) {
        param($Tags)

        Mock Get-AzResourceGroup { return @{Tags = $Tags } } -ParameterFilter { $Location -eq 'foo' -and $ResourceGroupName -eq 'bar' }
        Test-VoResourceGroupDeploymentAvailability `
            -Location 'foo' `
            -ResourceGroupName 'bar' `
            -ResourceGroupTags @{} `
        | Should -Be $true
    }

    It "Resource group's lock expired" {
        Mock Get-AzResourceGroup { return @{Tags = @{LockedUntil = [datetime]::UtcNow.AddMilliseconds(-1).ToString('u') } } } -ParameterFilter { $Location -eq 'foo' -and $ResourceGroupName -eq 'bar' }
        Test-VoResourceGroupDeploymentAvailability `
            -Location 'foo' `
            -ResourceGroupName 'bar' `
            -ResourceGroupTags @{} `
        | Should -Be $true
    }

    It 'Resource group is locked' {
        Mock Get-AzResourceGroup { return @{Tags = @{LockedUntil = [datetime]::UtcNow.AddDays(1).ToString('u') } } } -ParameterFilter { $Location -eq 'foo' -and $ResourceGroupName -eq 'bar' }
        Test-VoResourceGroupDeploymentAvailability `
            -Location 'foo' `
            -ResourceGroupName 'bar' `
            -ResourceGroupTags @{} `
        | Should -Be $false
    }
}
