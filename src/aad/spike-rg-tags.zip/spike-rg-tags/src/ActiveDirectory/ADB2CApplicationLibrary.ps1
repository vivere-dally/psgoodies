function Mount-VoADB2CApplication {
    [CmdletBinding()]
    [OutputType([psobject])]
    [Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseDeclaredVarsMoreThanAssignments', '')]
    param (
        [Parameter(Mandatory = $true)]
        [Microsoft.Azure.Commands.ResourceManager.Cmdlets.SdkModels.PSResourceGroup]
        $ResourceGroup,

        [Parameter(Mandatory = $true)]
        [Microsoft.Azure.Commands.ResourceManager.Cmdlets.SdkModels.PSResource]
        $Tenant,

        [Parameter(Mandatory = $true, Position = 0, ValueFromPipeline = $true)]
        [hashtable]
        $ADB2CApplicationSettings
    )

    begin {
        $tenantName = $Tenant.ResourceName.Split('.')[0]
    }

    process {
        New-VoLogMessage 'Start ADB2C application mounting'
        $ADB2CApplicationSettings.IdentifierUris = @($ADB2CApplicationSettings.IdentifierUris | ForEach-Object { $_ | Invoke-Expression })
        $ADB2CApplicationSettings.ReplyUrls.$Global:Kind = @($ADB2CApplicationSettings.ReplyUrls.$Global:Kind | ForEach-Object { $_ | Invoke-Expression })

        $TenantSession = Get-VoAzureTenantSession $Global:ContextName $Tenant.Properties.tenantId 'https://management.core.windows.net/'
        $application = Get-VoADB2CApplication $ADB2CApplicationSettings $TenantSession
        $application = if (-not $application) {
            New-VoADB2CApplication $ADB2CApplicationSettings $TenantSession
        }
        else {
            Set-VoADB2CApplication $application $ADB2CApplicationSettings $TenantSession
        }

        Get-VoADApplicationPermission $ADB2CApplicationSettings.Permissions | ForEach-Object {
            Set-AzureADB2CApplication `
                -B2CSession $TenantSession `
                -ApplicationId $application.applicationId `
                -RequiredResourceAccess $_
        }

        $application = Get-VoADB2CApplication $ADB2CApplicationSettings $TenantSession
        Write-VoLog "Granted administrator consent for $($application.applicationName)'s permission" -ForegroundColor DarkGreen

        Write-VoLog "Mounted ADB2C application $($application.applicationName)" -ForegroundColor DarkBlue
        New-VoLogMessage -Separator
        return $application
    }
}

function Get-VoADB2CApplication {
    [CmdletBinding()]
    [OutputType([psobject])]
    param (
        [Parameter(Mandatory = $true, Position = 0)]
        [hashtable]
        $ADB2CApplicationSettings,

        [Parameter(Mandatory = $true, Position = 1)]
        [psobject]
        $TenantSession
    )

    New-VoLogMessage 'Start ADB2C application fetching'

    $application = Get-AzureADApplication -SearchString $ADB2CApplicationSettings.Name
    if (-not $application) {
        Write-VoLog "The $($ADB2CApplicationSettings.Name) doesn't exist" -ForegroundColor DarkGray
        return $null
    }

    $application = Get-AzureADB2CApplication -B2CSession $TenantSession -ApplicationId $application.AppId | Out-VoHashtable
    Write-VoLog "Fetched ADB2C application $($application.applicationName)"
    return $application
}

function New-VoADB2CApplication {
    [CmdletBinding()]
    [OutputType([hashtable])]
    param (
        [Parameter(Mandatory = $true, Position = 0)]
        [hashtable]
        $ADB2CApplicationSettings,

        [Parameter(Mandatory = $true, Position = 1)]
        [psobject]
        $TenantSession
    )

    New-VoLogMessage 'Start ADB2C application creation'

    $scopes = $ADB2CApplicationSettings.Scopes | ForEach-Object { New-VoOAuth2Permission -DisplayName $_.DisplayName -Value $_.Value }
    $params = @{
        B2CSession         = $TenantSession;
        Name               = $ADB2CApplicationSettings.Name;
        EnableWebClient    = $ADB2CApplicationSettings.EnableWebClient;
        AllowImplicitFlow  = $ADB2CApplicationSettings.AllowImplicitFlow;
        EnableNativeClient = $ADB2CApplicationSettings.EnableNativeClient;
    }

    if ($ADB2CApplicationSettings.IdentifierUris.Length -gt 0) {
        $params.IdentifierUris = $ADB2CApplicationSettings.IdentifierUris
    }

    if ($ADB2CApplicationSettings.ReplyUrls.$Kind.Length -gt 0) {
        $params.ReplyUrls = $ADB2CApplicationSettings.ReplyUrls.$Kind
    }

    if ($scopes) {
        $params.OAuth2Permissions = $scopes
    }

    $application = New-AzureADB2CApplication @params | Select-Object -ExpandProperty 'Content' | ConvertFrom-Json | Out-VoHashtable
    Write-VoLog "Created ADB2C application $($application.applicationName)" -ForegroundColor DarkGreen

    return $application
}

function Set-VoADB2CApplication {
    [CmdletBinding()]
    [OutputType([hashtable])]
    param (
        [Parameter(Mandatory = $true, Position = 0)]
        [hashtable]
        $Application,

        [Parameter(Mandatory = $true, Position = 1)]
        [hashtable]
        $ADB2CApplicationSettings,

        [Parameter(Mandatory = $true, Position = 2)]
        [psobject]
        $TenantSession
    )

    New-VoLogMessage 'Start ADB2C application update'

    $params = @{ B2CSession = $TenantSession; ApplicationId = $Application.applicationId; }
    if ($ADB2CApplicationSettings.Name -ne $application.applicationName) {
        $params.Name = $ADB2CApplicationSettings.Name
    }

    if ($ADB2CApplicationSettings.AllowImplicitFlow -ne $application.webClientAllowImplicitFlow) {
        $params.AllowImplicitFlow = $ADB2CApplicationSettings.AllowImplicitFlow
    }

    if ($ADB2CApplicationSettings.EnableNativeClient -ne $application.enableNativeClient) {
        $params.enableNativeClient = $ADB2CApplicationSettings.EnableNativeClient
    }

    foreach ($comparison in (Compare-Object -ReferenceObject $ADB2CApplicationSettings.IdentifierUris -DifferenceObject $application.identifierUris -IncludeEqual)) {
        if ($comparison.InputObject -in $ADB2CApplicationSettings.IdentifierUris -and $comparison.SideIndicator -ne '==') {
            $params.IdentifierUris = $ADB2CApplicationSettings.IdentifierUris
            break
        }
    }

    foreach ($comparison in (Compare-Object -ReferenceObject $ADB2CApplicationSettings.ReplyUrls.$Global:Kind -DifferenceObject $application.replyUrls -IncludeEqual)) {
        if ($comparison.InputObject -in $ADB2CApplicationSettings.ReplyUrls.$Global:Kind -and $comparison.SideIndicator -ne '==') {
            $params.ReplyUrls = $ADB2CApplicationSettings.ReplyUrls.$Global:Kind
            break
        }
    }

    foreach ($comparison in (Compare-Object -ReferenceObject @($ADB2CApplicationSettings.Scopes | ForEach-Object { $_.Value }) -DifferenceObject @($Application.oAuth2Permissions | ForEach-Object { $_.value }) -IncludeEqual)) {
        if ($comparison.InputObject -in $ADB2CApplicationSettings.Scopes -and $comparison.SideIndicator -ne '==') {
            $scopes = $ADB2CApplicationSettings.Scopes | ForEach-Object { New-VoOAuth2Permission -DisplayName $_.DisplayName -Value $_.Value }
            $params.OAuth2Permissions = $scopes
            break
        }
    }

    if ($params.Keys.Count -gt 2) {
        Set-AzureADB2CApplication @params | Out-VoHashtable
        $currentApplication = { Get-AzureADB2CApplication -B2CSession $TenantSession -ApplicationId $Application.applicationId } | Use-VoRetryHandler -TimeoutSec 10
        Write-VoLog "Updated ADB2C application $($currentApplication.applicationName)" -ForegroundColor DarkYellow
        Format-VoObjectUpdate $Application $currentApplication | Write-VoLog -ForegroundColor DarkYellow
        $Application = $currentApplication
    }

    Write-VoLog "The ADB2C application $($Application.applicationName) is up to date"
    return $Application
}
