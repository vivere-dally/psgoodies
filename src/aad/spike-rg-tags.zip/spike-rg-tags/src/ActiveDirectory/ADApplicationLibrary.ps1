function Mount-VoADApplication {
    [CmdletBinding()]
    [OutputType([System.Tuple[[Microsoft.Open.AzureAD.Model.Application], [Microsoft.Open.AzureAD.Model.PasswordCredential]]])]
    [Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseDeclaredVarsMoreThanAssignments', '')]
    param (
        [Parameter(Mandatory = $true)]
        [Microsoft.Azure.Commands.ResourceManager.Cmdlets.SdkModels.PSResourceGroup]
        $ResourceGroup,

        [Parameter(Mandatory = $true)]
        [Microsoft.Azure.Commands.ResourceManager.Cmdlets.SdkModels.PSResource]
        $Tenant,

        [Parameter(Mandatory = $true, Position = 0, ValueFromPipeline = $true)]
        [hashtable]
        $ADApplicationSettings
    )

    begin {
        $tenantName = $Tenant.ResourceName.Split('.')[0]
    }

    process {
        New-VoLogMessage 'Start AD application mounting'
        $ADApplicationSettings.IdentifierUris = @($ADApplicationSettings.IdentifierUris | ForEach-Object { $_ | Invoke-Expression })
        $ADApplicationSettings.ReplyUrls.$Global:Kind = @($ADApplicationSettings.ReplyUrls.$Global:Kind | ForEach-Object { $_ | Invoke-Expression })
        $application = Get-AzureADApplication -Filter "DisplayName eq '$($ADApplicationSettings.Name)'"
        $application = if (-not $application) {
            Write-VoLog "The $($ADApplicationSettings.Name) doesn't exist" -ForegroundColor DarkGray
            New-VoADApplication $ResourceGroup $ADApplicationSettings
        }
        else {
            Write-VoLog "Fetched AD application $($application.DisplayName)"
            Set-VoADApplication $ResourceGroup $application $ADApplicationSettings
        }

        $ADApplicationSettings.ServicePrincipal | Mount-VoADServicePrincipal -Application $application

        Grant-VoADApplicationPermissions $application.AppId (Get-VoAzureTenantSession $Global:ContextName $Tenant.Properties.tenantId '74658136-14ec-4630-ad9b-26e160ff0fc6')
        Write-VoLog "Granted administrator consent for $($application.DisplayName)'s permission" -ForegroundColor DarkGreen
        if ($ADApplicationSettings.HasPasswordCredential) {
            Get-AzureADApplicationPasswordCredential -ObjectId $application.ObjectId | ForEach-Object { Remove-AzureADApplicationPasswordCredential -ObjectId $application.ObjectId -KeyId $_.KeyId }
            $clientSecret = New-AzureADApplicationPasswordCredential `
                -ObjectId $application.ObjectId `
                -CustomKeyIdentifier "$($application.DisplayName)VoClientSecret" `
                -StartDate (Get-Date) `
                -EndDate ((Get-Date).AddYears(200))
            Write-VoLog "Created AD client secret $([System.String]::new($clientSecret.CustomKeyIdentifier)) for $($application.DisplayName) AD application." -ForegroundColor DarkGreen
        }

        Write-VoLog "Mounted AD application $($application.DisplayName)" -ForegroundColor DarkBlue
        New-VoLogMessage -Separator
        return [System.Tuple[[Microsoft.Open.AzureAD.Model.Application], [Microsoft.Open.AzureAD.Model.PasswordCredential]]]::new($application, $clientSecret)
    }
}

function New-VoADApplication {
    [CmdletBinding()]
    [OutputType([Microsoft.Open.AzureAD.Model.Application])]
    param (
        [Parameter(Mandatory = $true, Position = 0)]
        [Microsoft.Azure.Commands.ResourceManager.Cmdlets.SdkModels.PSResourceGroup]
        $ResourceGroup,

        [Parameter(Mandatory = $true, Position = 1)]
        [hashtable]
        $ADApplicationSettings
    )

    New-VoLogMessage 'Start ADB2C application creation'
    $permissions = Get-VoADApplicationPermission $ADApplicationSettings.Permissions
    $application = New-AzureADApplication `
        -DisplayName $ADApplicationSettings.Name `
        -AvailableToOtherTenants $ADApplicationSettings.AvailableToOtherTenants `
        -PublicClient $ADApplicationSettings.PublicClient `
        -IdentifierUris $ADApplicationSettings.IdentifierUris `
        -ReplyUrls $ADApplicationSettings.ReplyUrls.$Global:Kind `
        -RequiredResourceAccess $permissions
    Write-VoLog "Created AD application $($application.DisplayName)" -ForegroundColor DarkGreen
    return $application
}

function Set-VoADApplication {
    [CmdletBinding()]
    [OutputType([Microsoft.Open.AzureAD.Model.Application])]
    param (
        [Parameter(Mandatory = $true, Position = 0)]
        [Microsoft.Azure.Commands.ResourceManager.Cmdlets.SdkModels.PSResourceGroup]
        $ResourceGroup,

        [Parameter(Mandatory = $true, Position = 1)]
        [Microsoft.Open.AzureAD.Model.Application]
        $Application,

        [Parameter(Mandatory = $true, Position = 2)]
        [hashtable]
        $ADApplicationSettings
    )

    New-VoLogMessage 'Start AD application update'
    $params = @{}
    if ($ADApplicationSettings.Name -ne $Application.DisplayName) {
        $params.DisplayName = $Application.Name
    }

    if ($ADApplicationSettings.AvailableToOtherTenants -ne $Application.AvailableToOtherTenants) {
        $params.AvailableToOtherTenants = $ADApplicationSettings.AvailableToOtherTenants
    }

    if ($ADApplicationSettings.PublicClient -ne $Application.PublicClient) {
        $params.PublicClient = $ADApplicationSettings.PublicClient
    }

    foreach ($comparison in (Compare-Object -ReferenceObject $ADApplicationSettings.IdentifierUris -DifferenceObject $Application.IdentifierUris -IncludeEqual)) {
        if ($comparison.InputObject -in $ADApplicationSettings.IdentifierUris -and $comparison.SideIndicator -ne '==') {
            $params.IdentifierUris = $ADApplicationSettings.IdentifierUris
            break
        }
    }

    foreach ($comparison in (Compare-Object -ReferenceObject $ADApplicationSettings.ReplyUrls.$Global:Kind -DifferenceObject $Application.ReplyUrls -IncludeEqual)) {
        if ($comparison.InputObject -in $ADApplicationSettings.ReplyUrls.$Global:Kind -and $comparison.SideIndicator -ne '==') {
            $params.ReplyUrls = $ADApplicationSettings.ReplyUrls.$Global:Kind
            break
        }
    }

    $permissions = Get-VoADApplicationPermission $ADApplicationSettings.Permissions
    foreach ($comparison in (Compare-Object -ReferenceObject $permissions -DifferenceObject $Application.RequiredResourceAccess -IncludeEqual)) {
        if ($comparison.SideIndicator -ne '==') {
            $params.RequiredResourceAccess = $permissions
            break
        }
    }

    if ($params.Keys.Count -gt 0) {
        $currentApplication = Set-AzureADApplication @params
        Write-VoLog "Updated AD application $($currentApplication.DisplayName)" -ForegroundColor DarkYellow
        Format-VoObjectUpdate $Application $currentApplication | Write-VoLog -ForegroundColor DarkYellow
        $Application = $currentApplication
    }

    Write-VoLog "The AD application $($Application.DisplayName) is up to date"
    return $Application
}

function Mount-VoADServicePrincipal {
    [CmdletBinding()]
    [OutputType([Microsoft.Open.AzureAD.Model.ServicePrincipal])]
    param (
        [Parameter(Mandatory = $true)]
        [Microsoft.Open.AzureAD.Model.Application]
        $Application,

        [Parameter(Mandatory = $true, Position = 0, ValueFromPipeline = $true)]
        [hashtable]
        $ADServicePrincipalSettings
    )

    begin {
        New-VoLogMessage 'Start AD service principal mounting'
    }

    process {
        Write-VoLog 'Start AD service principal fetching'
        $servicePrincipal = Get-AzureADServicePrincipal -Filter "DisplayName eq '$($Application.DisplayName)'"
        if (-not $servicePrincipal) {
            Write-VoLog "The service principal $($Application.DisplayName) doesn't exist" -ForegroundColor DarkGray
            $servicePrincipal = New-AzureADServicePrincipal `
                -AppId $Application.AppId `
                -AccountEnabled $ADServicePrincipalSettings.AccountEnabled

            Write-VoLog "Created AD service principal $($servicePrincipal.DisplayName)" -ForegroundColor DarkGreen
        }
        else {
            Write-VoLog "Fetched AD service principal $($servicePrincipal.DisplayName)"
        }

        Write-VoLog "Start granting needed roles to the AD service principal $($servicePrincipal.DisplayName)"
        $ADServicePrincipalSettings.ApplicationRoles | ForEach-Object {
            $adDirectoryRole = Get-AzureADDirectoryRole -Filter "DisplayName eq '$_'"
            if (-not $adDirectoryRole) {
                Write-VoLog "The directory role $_ isn't enabled at tenant level" -ForegroundColor DarkGray
                Write-VoLog "Start $_ directory role enabling"
                $adDirectoryRoleTemplate = Get-AzureADDirectoryRoleTemplate | Where-Object DisplayName -EQ $_
                if (-not $adDirectoryRoleTemplate) {
                    throw "Could not find $_ directory role template"
                }

                Write-VoLog "Found $_ directory role template"
                Enable-AzureADDirectoryRole -RoleTemplateId $adDirectoryRoleTemplate.ObjectId | Out-Null
                $adDirectoryRole = Get-AzureADDirectoryRole -Filter "DisplayName eq '$_'"
            }

            $memberDisplayNames = Get-AzureADDirectoryRoleMember -ObjectId $adDirectoryRole.ObjectId | Select-Object -ExpandProperty DisplayName
            if ($servicePrincipal.DisplayName -notin $memberDisplayNames) {
                Add-AzureADDirectoryRoleMember -ObjectId $adDirectoryRole.ObjectId -RefObjectId $servicePrincipal.ObjectId | Out-Null
                Write-VoLog "The directory role $_ has been assigned to the service principal $($servicePrincipal.DisplayName)" -ForegroundColor DarkGreen
            }
            else {
                Write-VoLog "The directory role $_ is already assigned to the service principal $($servicePrincipal.DisplayName)"
            }
        }

        Write-VoLog "Mounted AD service principal $($servicePrincipal.DisplayName)" -ForegroundColor DarkBlue
        return $servicePrincipal
    }
}
