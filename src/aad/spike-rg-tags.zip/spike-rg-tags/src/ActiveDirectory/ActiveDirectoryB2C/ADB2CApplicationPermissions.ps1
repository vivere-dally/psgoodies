function Get-AzureADB2CApplicationPermission {
    <#
    .SYNOPSIS
        Gets all permissions for a B2C application.
    .DESCRIPTION
        The Get-AzureADB2CApplicationPermissions cmdlet gets a list of permissions for an Azure Active Directory B2C application.
    .PARAMETER B2CSession
        Specifies a B2C session object containing the B2C tenant name and an OAuth2 access token.
    .PARAMETER ApplicationId
        Specifies the ID of an Azure Active Directory B2C application.
    .EXAMPLE
        PS C:\>Get-AzureADB2CApplicationPermission -B2CSession $b2csession -ApplicationId ed192e92-84d4-4baf-997d-1e190a81f28e
        This command gets a list of permissions for the given application.
    .LINK
        Set-AzureADB2CApplication
    #>
    [CmdletBinding()]
    Param(
        [parameter(Mandatory = $true, Position = 0)]
        [ValidateNotNullOrEmpty()]
        [PSCustomObject]$B2CSession,
        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [String]$ApplicationId
    )

    $uri = "https://main.b2cadmin.ext.azure.com/api/ApplicationV2/RetrievePermissions?tenantId=$($B2CSession.TenantId)&clientApplicationId=$ApplicationId"
    $headers = @{ "Authorization" = "Bearer $($B2CSession.AccessToken)"; "Accept" = "application/json, text/javascript, */*; q=0.01" }

    $response = $null
    try {
        $response = Invoke-WebRequest -Uri $uri -Headers $headers -ContentType "application/json" -ErrorAction SilentlyContinue -UseBasicParsing | ConvertFrom-Json
    }
    catch {
        Write-Host "The application doesn't have any permissions" -ForegroundColor Yellow
    }

    return $response
}

function Remove-AzureADB2CApplicationPermission {
    <#
    .SYNOPSIS
        Deletes a permission from a B2C application.
    .DESCRIPTION
        The Remove-AzureADB2CApplicationPermissions cmdlet deletes a permission from an Azure Active Directory B2C application.
    .PARAMETER B2CSession
        Specifies a B2C session object containing the B2C tenant name and an OAuth2 access token.
    .PARAMETER PermissionGrantId
        Specifies the ID of an Azure Active Directory B2C permission grant.
    .EXAMPLE
        PS C:\>Remove-AzureADB2CApplicationPermission -B2CSession $b2csession -PermissionGrantId <permissiongrantid>
        This command removes the grant with the given ID from your Azure AD B2C tenant.
    .LINK
        Not used
    #>
    [CmdletBinding(SupportsShouldProcess = $True)]
    Param(
        [parameter(Mandatory = $true, Position = 0)]
        [ValidateNotNullOrEmpty()]
        [PSCustomObject]$B2CSession,
        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [String]$PermissionGrantId
    )

    $uri = "https://main.b2cadmin.ext.azure.com/api/ApplicationV2/DeletePermission?tenantId=$($B2CSession.TenantId)&permissionGrantId=$PermissionGrantId"
    $headers = @{ "Authorization" = "Bearer $($B2CSession.AccessToken)"; "Accept" = "application/json, text/javascript, */*; q=0.01" }

    $response = $null
    if ($pscmdlet.ShouldProcess()) {
        $response = Invoke-WebRequest -Uri $uri -Method DELETE -Headers $headers -UseBasicParsing

        if (!($response.StatusCode -ge 200 -and $response.StatusCode -le 299)) {
            Write-Error "Failed to remove Permission Grant"
            return
        }
    }

    return $response
}
