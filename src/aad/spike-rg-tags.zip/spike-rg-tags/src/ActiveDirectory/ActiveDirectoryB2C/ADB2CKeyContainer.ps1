function Get-AzureADB2CKeyContainer {
    <#
    .SYNOPSIS
        Gets a B2C keycontainer.
    .DESCRIPTION
        The Get-AzureADB2CKeyContainer cmdlet gets an Azure AD B2C directory keycontainer.
    .PARAMETER B2CSession
        Specifies a B2C session object containing the B2C tenant name and an OAuth2 access token.
    .PARAMETER Name
        Specifies the name of a keycontainer in Azure AD B2C.
    .EXAMPLE
        PS C:\>Get-AzureADB2CKeyContainer -B2CSession <b2csession>
        This command gets all keycontainers of your Azure AD B2C tenant
    .LINK
        New-AzureADB2CKeyContainer
        Remove-AzureADB2CKeyContainer
    #>
    [CmdletBinding()]
    Param(
        [parameter(Mandatory = $true, Position = 0)]
        [ValidateNotNullOrEmpty()]
        [PSCustomObject]$B2CSession,
        [parameter(Mandatory = $false, Position = 1)]
        [ValidateNotNullOrEmpty()]
        [string]$Name
    )

    $uri = "https://main.b2cadmin.ext.azure.com/api/Jwks/GetKeyList?tenantId=$($B2CSession.TenantId)&options=6"
    if ($Name) {
        $uri = "https://main.b2cadmin.ext.azure.com/api/Jwks/GetKeySetMetadata?tenantId=$($B2CSession.TenantId)&storageReferenceId=$Name"
    }
    $headers = @{ "Authorization" = "Bearer $($B2CSession.AccessToken)"; "Accept" = "application/json, text/javascript, */*; q=0.01" }

    $response = $null
    try {
        $response = Invoke-WebRequest -Uri $uri -Headers $headers -ContentType "application/json" -UseBasicParsing | ConvertFrom-Json
    }
    catch {
        return $null
    }
    
    return $response
}

function New-AzureADB2CKeyContainer {
    <#
    .SYNOPSIS
        Creates a B2C RSA keycontainer.
    .DESCRIPTION
        The New-AzureADB2CKeyContainer cmdlet creates an Azure Active Directory B2C RSA keycontainer.
        The keycontainer can be used for encryption or signing.
    .PARAMETER B2CSession
        Specifies a B2C session object containing the B2C tenant name and an OAuth2 access token.
    .PARAMETER Name
        Specifies the name of a keycontainer.
    .PARAMETER KeyUsage
        Specifies the key usage
        The acceptable values for this paramter are:
        - enc
        - sig
    .EXAMPLE
        PS C:\>New-AzureADB2CKeyContainer -B2CSession <b2csession> -Name "New Name" -KeyUsage enc
        This command creates a new keycontainer for encryption in your Azure AD B2C tenant
    .EXAMPLE
        PS C:\>New-AzureADB2CKeyContainer -B2CSession <b2csession> -Name "New Name" -KeyUsage sig
        This command creates a new keycontainer for signing in your Azure AD B2C tenant
    .LINK
        Get-AzureADB2CKeyContainer
        Remove-AzureADB2CKeyContainer
    #>
    [CmdletBinding(SupportsShouldProcess = $True)]
    Param(
        [parameter(Mandatory = $true, Position = 0)]
        [ValidateNotNullOrEmpty()]
        [PSCustomObject]$B2CSession,
        [parameter(Mandatory = $true, Position = 1)]
        [ValidateNotNullOrEmpty()]
        [String]$Name,
        [parameter(Mandatory = $true, Position = 2)]
        [ValidateSet(
            'enc',
            'sig'
        )]
        [ValidateNotNullOrEmpty()]
        [String]$KeyUsage
    )

    $uri = "https://main.b2cadmin.ext.azure.com/api/Jwks/PutNewKey?tenantId=$($B2CSession.TenantId)&storageReferenceId=$Name&secretType=rsa&keySize=0&keyUsage=$KeyUsage"
    $headers = @{ "Authorization" = "Bearer $($B2CSession.AccessToken)" }

    if ($pscmdlet.ShouldProcess($Name)) {
        $response = $null
        $response = Invoke-WebRequest -Uri $uri -Method PUT -Headers $headers -UseBasicParsing

        if (!($response.StatusCode -ge 200 -and $response.StatusCode -le 299)) {
            Write-Error "Failed to create keycontainer"
            return
        }
    }
}

function Remove-AzureADB2CKeyContainer {
    <#
    .SYNOPSIS
        Deletes a B2C keycontainer by name.
    .DESCRIPTION
        The Remove-AzureADB2CKeyContainer cmdlet removes an Azure Active Directory B2C keycontainer.
        Azure AD B2C will automatically create a backup with the same name followed by a .bak extension.
        Also remove this keycontainer if you want to fully delete the keycontainer.
    .PARAMETER B2CSession
        Specifies a B2C session object containing the B2C tenant name and an OAuth2 access token.
    .PARAMETER Name
        Specifies the name of a keycontainer.
    .EXAMPLE
        PS C:\>Remove-AzureADB2CKeyContainer -B2CSession <b2csession> -KeyName <string>
        This command removes the keycontainer with the given name from your Azure AD B2C tenant
    .EXAMPLE
        PS C:\>Remove-AzureADB2CKeyContainer -B2CSession <b2csession> -KeyName <string>.bak
        This command removes the backup of the keycontainer with the given name from your Azure AD B2C tenant
    .LINK
        Get-AzureADB2CKeyContainer
        New-AzureADB2CKeyContainer
    #>
    [CmdletBinding(SupportsShouldProcess = $True)]
    Param(
        [parameter(Mandatory = $true, Position = 0)]
        [ValidateNotNullOrEmpty()]
        [PSCustomObject]$B2CSession,
        [parameter(Mandatory = $true, Position = 1)]
        [ValidateNotNullOrEmpty()]
        [String]$Name
    )

    $uri = "https://main.b2cadmin.ext.azure.com/api/Jwks/DeleteKeySet?tenantId=$($B2CSession.TenantId)&storageReferenceId=$Name"
    $headers = @{ "Authorization" = "Bearer $($B2CSession.AccessToken)"; "Accept" = "application/json, text/javascript, */*; q=0.01" }

    if ($pscmdlet.ShouldProcess($Name)) {
        $response = $null
        $response = Invoke-WebRequest -Uri $uri -Method DELETE -Headers $headers -UseBasicParsing

        if (!($response.StatusCode -ge 200 -and $response.StatusCode -le 299)) {
            Write-Error "Failed to Remove-AzureADB2CKeyContainer"
            return
        }
    }
}
