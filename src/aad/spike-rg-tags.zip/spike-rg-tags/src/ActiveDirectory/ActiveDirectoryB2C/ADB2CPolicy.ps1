function Get-AzureADB2CPolicy {
    <#
    .SYNOPSIS
        Gets an B2C policy.
    .DESCRIPTION
        The Get-AzureADB2CPolicy cmdlet gets an Azure Active Directory B2C policy.
    .PARAMETER B2CSession
        Specifies a B2C session object containing the B2C tenant name and an OAuth2 access token.
    .EXAMPLE
        PS C:\>Get-AzureADB2CPolicy -B2CSession <b2csession>
        This command gets a list of policy names from your Azure AD B2C tenant
    .LINK
        New-AzureADB2CPolicy
        Remove-AzureADB2CPolicy
    #>
    [CmdletBinding()]
    Param(
        [parameter(Mandatory = $true, Position = 0)]
        [ValidateNotNullOrEmpty()]
        [PSCustomObject]$B2CSession
    )

    $uri = "https://main.b2cadmin.ext.azure.com/api/policyList?tenantId=$($B2CSession.TenantId)"
    $headers = @{ "Authorization" = "Bearer $($B2CSession.AccessToken)"; "Accept" = "application/json, text/javascript, */*; q=0.01" }

    $response = $null
    $response = Invoke-WebRequest -Uri $uri -Headers $headers -ContentType "application/json" -UseBasicParsing | ConvertFrom-Json
    return $response
}

function New-AzureADB2CPolicy {
    <#
    .SYNOPSIS
        Creates a B2C policy.
    .DESCRIPTION
        The New-AzureADB2CPolicy cmdlet creates an Azure Active Directory B2C policy.
    .PARAMETER B2CSession
        Specifies a B2C session object containing the B2C tenant name and an OAuth2 access token.
    .PARAMETER Policy
        Specifies a XML policy.
    .PARAMETER FilePath
        Specifies a path to a file.
    .EXAMPLE
        PS C:\>New-AzureADB2CPolicy -B2CSession <b2csession> -Policy <string>
        This command creates a policy from a string in your Azure AD B2C tenant
    .EXAMPLE
        PS C:\>New-AzureADB2CPolicy -B2CSession <b2csession> -FilePath <path>
        This command creates a policy from a file in your Azure AD B2C tenant
    .LINK
        Get-AzureADB2CPolicy
        Remove-AzureADB2CPolicy
    #>
    [CmdletBinding(SupportsShouldProcess = $True)]
    Param(
        [parameter(Mandatory = $true, Position = 0, ParameterSetName = "Policy")]
        [parameter(Mandatory = $true, Position = 0, ParameterSetName = "PolicyFile")]
        [ValidateNotNullOrEmpty()]
        [PSCustomObject]$B2CSession,
        [parameter(Mandatory = $true, ParameterSetName = "Policy")]
        [ValidateNotNullOrEmpty()]
        [String]$Policy,
        [parameter(Mandatory = $true, ParameterSetName = "PolicyFile")]
        [ValidateNotNullOrEmpty()]
        [ValidateScript( { Test-Path -Path $_ -PathType Leaf })]
        [String]$FilePath
    )

    if ($FilePath) {
        $Policy = (Get-Content -Path $FilePath -Encoding UTF8) -join "`n"
    }

    $uri = "https://main.b2cadmin.ext.azure.com/api/trustframework?tenantId=$($B2CSession.TenantId)&overwriteIfExists=true"
    $headers = @{ "Authorization" = "Bearer $($B2CSession.AccessToken)" }

    Add-Type -AssemblyName System.Web
    $body = "<string xmlns=`"http://schemas.microsoft.com/2003/10/Serialization/`">$([System.Web.HttpUtility]::HtmlEncode($Policy))</string>"

    if ($pscmdlet.ShouldProcess("policy")) {
        $response = $null
        $response = Invoke-WebRequest -Uri $uri -Method POST -Body $body -ContentType "application/xml" -Headers $headers -UseBasicParsing

        if (!($response.StatusCode -ge 200 -and $response.StatusCode -le 299)) {
            Write-Error "Failed to create policy"
            return
        }
    }
}

function Remove-AzureADB2CPolicy {
    <#
    .SYNOPSIS
        Deletes a B2C policy
    .DESCRIPTION
        The Remove-AzureADB2CPolicy cmdlet removes the specified policy from Azure Active Directory B2C.
    .PARAMETER B2CSession
        Specifies a B2C session object containing the B2C tenant name and an OAuth2 access token.
    .PARAMETER PolicyId
        Specifies the ID of a policy in Azure AD B2C.
    .EXAMPLE
        PS C:\>Remove-AzureADB2CPolicy -B2CSession <b2csession> -PolicyId <string>
        This command removes the policy with the given policyId from your Azure AD B2C tenant
    .LINK
        Get-AzureADB2CPolicy
        New-AzureADB2CPolicy
    #>
    [CmdletBinding(SupportsShouldProcess = $True)]
    Param(
        [parameter(Mandatory = $true, Position = 0)]
        [ValidateNotNullOrEmpty()]
        [PSCustomObject]$B2CSession,
        [parameter(Mandatory = $true, Position = 1)]
        [ValidateNotNullOrEmpty()]
        [String]$PolicyId
    )

    $uri = "https://main.b2cadmin.ext.azure.com/api/trustframework?tenantId=$($B2CSession.TenantId)&policyId=$PolicyId"
    $headers = @{ "Authorization" = "Bearer $($B2CSession.AccessToken)"; "Accept" = "application/json, text/javascript, */*; q=0.01" }

    if ($pscmdlet.ShouldProcess($PolicyId)) {
        $response = $null
        $response = Invoke-WebRequest -Uri $uri -Method DELETE -Headers $headers -UseBasicParsing

        if (!($response.StatusCode -ge 200 -and $response.StatusCode -le 299)) {
            Write-Error "Failed to remove policy"
            return
        }
    }
}
