function Get-VoADApplicationPermission {
    [CmdletBinding()]
    [OutputType([System.Collections.Generic.List[Microsoft.Open.AzureAD.Model.RequiredResourceAccess]])]
    param (
        [Parameter(Mandatory = $true, Position = 0)]
        [hashtable[]]
        $PermissionSettings
    )

    New-VoLogMessage 'Start AD application permission fetching'

    $permissions = [System.Collections.Generic.List[Microsoft.Open.AzureAD.Model.RequiredResourceAccess]]::new()
    foreach ($group in ($PermissionSettings | Group-Object -Property { $_.OwnerApplication })) {
        Write-VoLog "Fetching Service Principal $($group.Name)"
        $servicePrincipal = {
            $sp = Get-AzureADServicePrincipal -Filter "DisplayName eq '$($group.Name)'"
            if (-not $sp) {
                throw "Service Principal named $($group.Name) not found."
            }

            return $sp
        } | Use-VoRetryHandler -TimeoutSec 10 -Retries 32 -Verbose

        Write-VoLog "Service Principal $($servicePrincipal.DisplayName) fetched"
        $groupPermissions = [Microsoft.Open.AzureAD.Model.RequiredResourceAccess]::new($servicePrincipal.AppId, [System.Collections.Generic.List[Microsoft.Open.AzureAD.Model.ResourceAccess]]::new())
        Write-VoLog "Fetching permissions from $($servicePrincipal.DisplayName)"
        foreach ($permission in $group.Group) {
            $permissionId = $(
                switch ($permission.Type) {
                    'Role' { $servicePrincipal.AppRoles; break; }
                    'Scope' { $servicePrincipal.OAuth2Permissions; break; }
                    Default { throw "Application permissions are misconfigured, the type $_ is not handled!" }
                }
            ) | Where-Object Value -EQ $permission.Name | Select-Object -ExpandProperty Id

            Write-VoLog "Fetched permission $($permission.Name)"
            $groupPermissions.ResourceAccess.Add([Microsoft.Open.AzureAD.Model.ResourceAccess]::new($permissionId, $permission.Type))
        }

        Write-VoLog "Fetched all permission from $($servicePrincipal.DisplayName)"
        $permissions.Add($groupPermissions)
    }

    Write-VoLog "Fetched all permission"
    return $permissions
}

function New-VoOAuth2Permission {
    <#
    .SYNOPSIS
        Creates an OAuth2Permission object
    .DESCRIPTION
        This cmdlet creates an OAuth2Permission object used for exposing API scopes by an ADB2C Application.
    .EXAMPLE
        PS C:\> New-VoOAuth2Permission -Value $value -DisplayName $displayName -Type $type
        This command creates an OAuth2Permssion object with the specified $value, $displayName and $type.
    .OUTPUTS
        PSCustomObject
    #>
    [CmdletBinding()]
    [OutputType([PSCustomObject])]
    param (
        [Parameter(Mandatory = $true)]
        [string]
        $Value,

        [Parameter(Mandatory = $true)]
        [string]
        $DisplayName,

        [Parameter(Mandatory = $false)]
        [string]
        $Type = "User"
    )

    return [PSCustomObject]@{
        id          = New-Guid;
        displayName = $DisplayName;
        value       = $Value;
        isEnabled   = $true;
        type        = $Type
    }
}

function Grant-VoADApplicationPermissions {
    <#
    .SYNOPSIS
        Grants Admin Consent to an AD Application
    .DESCRIPTION
        This cmdlet grants Administrator Consent to all the permissions an AD Application tries to access.
    .PARAMETER TenantId
        Specifies the Tenant Id.
    .PARAMETER ApplicationId
        Specifies the Application Id.
    .EXAMPLE
        PS C:\> Grant-VoADApplicationPermissions -TenantId $TenantId -ApplicationId $applicationId
        This command grants Administrator Consent for the Application specified by $applicationId in the tenant specified by $tenantId.
    .NOTES
        This cmdlet requires that you previously connected to Azure via Connect-VoToAzure.
    #>
    [CmdletBinding()]
    [OutputType()]
    param (
        [Parameter(Mandatory = $true, Position = 0)]
        [string]
        $ApplicationId,

        [Parameter(Mandatory = $true, Position = 1)]
        [PSCustomObject]
        $B2CSession
    )

    $url = "https://main.iam.ad.ext.azure.com/api/RegisteredApplications/$($ApplicationId)/Consent?onBehalfOfAll=true"
    $headers = @{
        "Authorization"          = "Bearer $($B2CSession.AccessToken)";
        'X-Requested-With'       = 'XMLHttpRequest';
        'x-ms-client-request-id' = [guid]::NewGuid();
        'x-ms-correlation-id'    = [guid]::NewGuid();
    }

    {
        $response = Invoke-WebRequest -Uri $url -Headers $headers -Method Post -UseBasicParsing -ErrorAction SilentlyContinue
        if (-not $response -or -not ($response.StatusCode -ge 200 -and $response.StatusCode -le 299)) {
            throw "Status code $($response.StatusCode)"
        }
    } | Use-VoRetryHandler -TimeoutSec 10 -Retries 32  -Verbose
}
