function Mount-VoADB2CTenant {
    [CmdletBinding()]
    [OutputType([Microsoft.Azure.Commands.ResourceManager.Cmdlets.SdkModels.PSResource])]
    param (
        [Parameter(Mandatory = $true)]
        [Microsoft.Azure.Commands.ResourceManager.Cmdlets.SdkModels.PSResourceGroup]
        $ResourceGroup,

        [Parameter(Mandatory = $true, Position = 0, ValueFromPipeline = $true)]
        [hashtable]
        $ADB2CTenantSettings
    )

    New-VoLogMessage 'Start Tenant mounting'

    $tenant = Get-VoADB2CTenant $ResourceGroup $ADB2CTenantSettings
    if (-not $tenant) {
        $tenant = New-VoADB2CTenant $ResourceGroup $ADB2CTenantSettings
    }

    $tenant | Disable-VoADB2CTenantMFA
    Write-VoLog "Mounted tenant $($tenant.ResourceName)" -ForegroundColor DarkBlue
    New-VoLogMessage -Separator
    return $tenant
}

function Get-VoADB2CTenant {
    [CmdletBinding()]
    [OutputType([Microsoft.Azure.Commands.ResourceManager.Cmdlets.SdkModels.PSResource])]
    param (
        [Parameter(Mandatory = $true, Position = 0)]
        [Microsoft.Azure.Commands.ResourceManager.Cmdlets.SdkModels.PSResourceGroup]
        $ResourceGroup,

        [Parameter(Mandatory = $true, Position = 1)]
        [hashtable]
        $ADB2CTenantSettings
    )

    New-VoLogMessage 'Start Tenant fetching'

    $tenantName = "$($ResourceGroup.ResourceGroupName)$($ADB2CTenantSettings.Suffix)"
    $tenant = Get-AzResource `
        -ResourceGroupName $ResourceGroup.ResourceGroupName `
        -Name $tenantName `
        -ExpandProperties `
        -ErrorAction SilentlyContinue
    if (-not $tenant) {
        Write-VoLog "The $tenantName doesn't exist" -ForegroundColor DarkGray
        return $null
    }

    Write-VoLog "Fetched tenant $($tenant.ResourceName)"
    return $tenant
}

function New-VoADB2CTenant {
    [CmdletBinding()]
    [OutputType([Microsoft.Azure.Commands.ResourceManager.Cmdlets.SdkModels.PSResource])]
    param (
        [Parameter(Mandatory = $true, Position = 0)]
        [Microsoft.Azure.Commands.ResourceManager.Cmdlets.SdkModels.PSResourceGroup]
        $ResourceGroup,

        [Parameter(Mandatory = $true, Position = 1)]
        [hashtable]
        $ADB2CTenantSettings
    )

    New-VoLogMessage 'Start Tenant creation'

    $tenantName = "$($ResourceGroup.ResourceGroupName)$($ADB2CTenantSettings.Suffix)"
    $tenant = New-AzResource `
        -Location $ADB2CTenantSettings.Location `
        -ApiVersion $ADB2CTenantSettings.ApiVersion `
        -ResourceGroupName $ResourceGroup.ResourceGroupName `
        -ResourceName $tenantName `
        -ResourceType $ADB2CTenantSettings.ResourceType `
        -Sku $ADB2CTenantSettings.Sku `
        -Properties $ADB2CTenantSettings['Properties'] `
        -Force `
        -ErrorAction Stop

    $tenant = {
        $t = Get-AzResource `
            -ResourceGroupName $ResourceGroup.ResourceGroupName `
            -Name $tenantName `
            -ExpandProperties `
            -ErrorAction SilentlyContinue
        if (-not $t) {
            throw "The tenant has been created but is not yet available to the GET operation."
        }

        return $t
    } | Use-VoRetryHandler -TimeoutSec 10 -Retries 32 -Verbose

    Write-VoLog "Created tenant $($tenant.ResourceName)" -ForegroundColor DarkGreen
    return $tenant
}

function Disable-VoADB2CTenantMFA {
    [CmdletBinding()]
    [OutputType()]
    param (
        [Parameter(Mandatory = $true, Position = 0, ValueFromPipeline = $true)]
        [Microsoft.Azure.Commands.ResourceManager.Cmdlets.SdkModels.PSResource]
        $Tenant
    )

    $TenantSession = Get-VoAzureTenantSession $Global:ContextName $Tenant.Properties.tenantId -Resource '74658136-14ec-4630-ad9b-26e160ff0fc6'
    $uri = 'https://main.iam.ad.ext.azure.com/api/SecurityDefaults/UpdateSecurityDefaultOnSave?enableSecurityDefaults=false'

    {
        $response = Invoke-WebRequest -Uri $uri -Method Put -Headers @{
            'Authorization'          = "Bearer $($TenantSession.AccessToken)"
            'x-ms-client-request-id' = ([guid]::NewGuid().Guid)
        } -UseBasicParsing -ErrorAction SilentlyContinue

        if (-not $response -or ($response.StatusCode -lt 200 -and $response.StatusCode -gt 299)) {
            throw "Bad status code: $($response.StatusCode)"
        }
    } | Use-VoRetryHandler -TimeoutSec 10 -Retries 32 -Verbose

    Write-VoLog "Disabled MFA for the tenant $TenantId" -ForegroundColor DarkBlue
}

function Initialize-VoADB2CTenant {
    [CmdletBinding()]
    [OutputType()]
    param (
        [Parameter(Mandatory = $true, Position = 0, ValueFromPipeline = $true)]
        [Microsoft.Azure.Commands.ResourceManager.Cmdlets.SdkModels.PSResource]
        $Tenant
    )

    New-VoLogMessage 'Start Tenant initialization'

    $b2cExtensionAppName = 'b2c-extensions-app. Do not modify. Used by AADB2C for storing user data.'
    $b2cExtensionApp = Get-AzureADApplication -Filter "DisplayName eq '$b2cExtensionAppName'" -ErrorAction SilentlyContinue
    if (-not $b2cExtensionApp) {
        $TenantSession = Get-VoAzureTenantSession $Global:ContextName $Tenant.Properties.tenantId -Resource 'https://management.core.windows.net/'
        $uri = "https://main.b2cadmin.ext.azure.com/api/tenants/GetAndInitializeTenantPolicy?tenantId=$($Tenant.Name)&skipInitialization=false"

        {
            $response = Invoke-WebRequest -Uri $uri -Method Get -Headers @{
                'Authorization'          = "Bearer $($TenantSession.AccessToken)"
                'x-ms-client-request-id' = ([guid]::NewGuid().Guid)
            } -UseBasicParsing -ErrorAction SilentlyContinue

            if (-not $response -or ($response.StatusCode -lt 200 -and $response.StatusCode -gt 299)) {
                throw "Bad status code: $($response.StatusCode)"
            }
        } | Use-VoRetryHandler -TimeoutSec 10 -Retries 32 -Verbose

        try {
            {
                $app = Get-AzureADApplication -Filter "DisplayName eq '$b2cExtensionAppName'" -ErrorAction Stop
                if (-not $app) {
                    throw "Could not find app: $b2cExtensionAppName"
                }
            } | Use-VoRetryHandler -TimeoutSec 10 -Retries 32 -Verbose
        }
        catch {
            throw @"
Could not initialize the Tenant programatically.
You should manually perform a login step in the Azure portal.
Make sure that the application: $b2cExtensionAppName; exists.
"@
        }
    }

    Write-VoLog "Initialized Tenant $($Tenant.Name)" -ForegroundColor DarkBlue
}
