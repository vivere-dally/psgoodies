[CmdletBinding()]
[OutputType()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseDeclaredVarsMoreThanAssignments', '')]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingPlainTextForPassword', '')]
param (
    [Parameter(Mandatory = $true)]
    [string]
    $SubscriptionId,

    [Parameter(Mandatory = $true)]
    [string]
    $AzureAdministratorEmail,

    [Parameter(Mandatory = $true)]
    [string]
    $AzureAdministratorPassword,

    [Parameter(Mandatory = $true)]
    [string]
    $ResourceGroupName,

    [Parameter(Mandatory = $false)]
    [string]
    $Location = 'westeurope',

    [Parameter(Mandatory = $false)]
    [ValidateSet("Development", "Production")]
    [string]
    $Kind = 'Development',

    [Parameter(Mandatory = $true)]
    [string]
    $ResourceGroupTagsData
)

function Main {
    try {
        $Settings = @{}
        Get-ChildItem -Path $PSScriptRoot -Filter '*Settings.json' -Recurse | ForEach-Object {
            $key = $_.BaseName.Replace('Settings', '')
            $Settings.$key = Get-Content -Path $_.FullName | ConvertFrom-Json | Out-VoHashtable -Depth 10
        }

        Add-VoLogPath "$PSScriptRoot\..\deploy.log" -ClearContent
        New-VoLogMessage "Start deployment on Resource Group $ResourceGroupName"

        # Az.Accounts
        $global:ContextName = New-VoCredential $AzureAdministratorEmail $AzureAdministratorPassword | Connect-VoToAzure -SubscriptionId $SubscriptionId

        # Az.Resources
        if (-not (Test-VoResourceGroupDeploymentAvailability -Location $Location -ResourceGroupName $ResourceGroupName -ResourceGroupTags $Global:ResourceGroupTags)) {
            Write-VoResourceGroupLockMessage -Location $Location -ResourceGroupName $ResourceGroupName
        }

        if ('Force' -in $Global:ResourceGroupTags.Keys) { $Global:ResourceGroupTags.Remove('Force'); }
        $Global:ResourceGroupTags += @{
            AzVersion      = '4.8.0';
            DeploymentTime = [DateTime]::UtcNow.ToString('u');
            DeploymentType = 'vo';
        };

        $resourceGroup = Mount-VoResourceGroup $Location $ResourceGroupName $Global:ResourceGroupTags
        $tenant = $Settings.ADB2CTenant | Mount-VoADB2CTenant -ResourceGroup $resourceGroup

        # AzureAD & REST
        $adSession = New-VoCredential $AzureAdministratorEmail $AzureAdministratorPassword | Connect-VoToAzureAD -TenantId $tenant.Properties.tenantId
        $tenant | Initialize-VoADB2CTenant
        $adApplicationTuple = $Settings.ADApplication | Mount-VoADApplication -ResourceGroup $resourceGroup -Tenant $tenant
        $adb2cApplications = $Settings.ADB2CApplication | Mount-VoADB2CApplication -ResourceGroup $resourceGroup -Tenant $tenant

        'SUCCESS!' | Write-VoLog -ForegroundColor DarkGreen
        exit 0
    }
    catch {
        $_
        $_.FullyQualifiedErrorId | Write-VoLog -Level ERROR -ForegroundColor DarkRed
        $_.ScriptStackTrace | Write-VoLog -Level ERROR -ForegroundColor DarkRed
        'FAILURE!' | Write-VoLog -ForegroundColor DarkRed
        exit 1
    }
    finally {
        if ($contextName) {
            $contextName | Disconnect-VoFromAzure
            Disconnect-VoFromAzureAD $AzureAdministratorEmail
        }
    }
}

#Requires -Version 5.1
#Requires -PSEdition Desktop
#Requires -Module @{ ModuleName = 'AzureAD'; RequiredVersion = '2.0.2.128' }
#Requires -Module @{ ModuleName = 'Az.Accounts'; RequiredVersion = '1.9.5' }
#Requires -Module @{ ModuleName = 'Az.Resources'; RequiredVersion = '2.5.1' }
#Requires -Module @{ ModuleName = 'VigilantOnlinePowershellUtils'; RequiredVersion = '1.0.3' }

[System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls -bor `
    [System.Net.SecurityProtocolType]::Tls11 -bor `
    [System.Net.SecurityProtocolType]::Tls12 -bor `
    [System.Net.SecurityProtocolType]::Tls13

$libraries = Get-ChildItem -Path $PSScriptRoot -Filter '*.ps1' -Recurse | Where-Object BaseName -NE 'Deploy' | Select-Object -ExpandProperty FullName
Import-Module -Name $libraries -Global -Force

$Global:VoLogAnsiPreference = 'Set'
$Global:ErrorActionPreference = 'Stop'
$Global:Kind = $Kind
$Global:ResourceGroupTags = $ResourceGroupTagsData | ConvertFrom-StringData

Main
