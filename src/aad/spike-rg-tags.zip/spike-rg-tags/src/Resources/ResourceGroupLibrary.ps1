function Mount-VoResourceGroup {
    [CmdletBinding()]
    [OutputType([Microsoft.Azure.Commands.ResourceManager.Cmdlets.SdkModels.PSResourceGroup])]
    param (
        [Parameter(Mandatory = $true, Position = 0)]
        [string]
        $Location,

        [Parameter(Mandatory = $true, Position = 1)]
        [string]
        $ResourceGroupName,

        [Parameter(Mandatory = $true, Position = 2)]
        [hashtable]
        $ResourceGroupTags
    )

    New-VoLogMessage 'Start Resource Group mounting'

    $resourceGroup = Get-AzResourceGroup -Location $Location -Name $ResourceGroupName -ErrorAction SilentlyContinue
    if (-not $resourceGroup) {
        $resourceGroup = New-AzResourceGroup -Location $Location -Name $ResourceGroupName -Tag $ResourceGroupTags
        Write-VoLog "Created Resource Group $($resourceGroup.ResourceGroupName)" -ForegroundColor DarkGreen
    }
    else {
        Write-VoLog "Fetched Resource Group $($resourceGroup.ResourceGroupName)"
        $updateResourceGroup = Set-AzResourceGroup -Name $ResourceGroupName -Tag $ResourceGroupTags

        Write-VoLog "Updated Resource Group $($updateResourceGroup.ResourceGroupName)" -ForegroundColor DarkYellow
        Format-VoObjectUpdate $resourceGroup $updateResourceGroup -Ignore TagsTable | Write-VoLog -ForegroundColor DarkYellow
        $resourceGroup = $updateResourceGroup
    }

    Write-VoLog "Mounted Resource Group $($resourceGroup.ResourceGroupName)" -ForegroundColor DarkBlue
    New-VoLogMessage -Separator
    return $resourceGroup
}

function Test-VoResourceGroupDeploymentAvailability {
    [CmdletBinding()]
    [OutputType([bool])]
    param (
        [Parameter(Mandatory = $true, Position = 0)]
        [string]
        $Location,

        [Parameter(Mandatory = $true, Position = 1)]
        [string]
        $ResourceGroupName,

        [Parameter(Mandatory = $true, Position = 2)]
        [AllowEmptyCollection()]
        [hashtable]
        $ResourceGroupTags
    )

    $f = 'Force'
    if ($f -in $ResourceGroupTags.Keys -and $ResourceGroupTags.$f -eq $true) {
        return $true
    }

    $resourceGroup = Get-AzResourceGroup -Location $Location -Name $ResourceGroupName -ErrorAction SilentlyContinue
    if (-not $resourceGroup) {
        return $true
    }

    $lu = 'LockedUntil'
    if ($lu -notin $resourceGroup.Tags.Keys -or
        [string]::IsNullOrEmpty($resourceGroup.Tags.$lu) -or
        -not [bool]($resourceGroup.Tags.$lu -as [datetime])) {
        return $true
    }

    $now = [datetime]([datetime]::UtcNow.ToString('u'))
    $lockDate = [datetime]$resourceGroup.Tags.$lu
    if ($lockDate.CompareTo($now) -le 0) {
        return $true
    }

    return $false
}

function Write-VoResourceGroupLockMessage {
    [CmdletBinding()]
    [OutputType()]
    param (
        [Parameter(Mandatory = $true, Position = 0)]
        [string]
        $Location,

        [Parameter(Mandatory = $true, Position = 1)]
        [string]
        $ResourceGroupName
    )

    $resourceGroup = Get-AzResourceGroup -Location $Location -Name $ResourceGroupName
    $reason = if ('Reason' -in $resourceGroup.Tags.Keys) { $resourceGroup.Tags['Reason'] } else { 'N/A' }
    $author = if ('Author' -in $resourceGroup.Tags.Keys) { $resourceGroup.Tags['Author'] } else { 'N/A' }
    $message = "Cannot deploy to Resource Group $($resourceGroup.ResourceGroupName) because it is locked until $($resourceGroup.Tags['LockedUntil']) UTC by $author.`nReason: $reason"
    throw $message
}
